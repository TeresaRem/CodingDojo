//
//  Memory.swift
//  customCellDemo
//
//  Created by Amy Giver on 9/14/16.
//  Copyright © 2016 Amy Giver Squid. All rights reserved.
//

import Foundation
import CoreData


class Memory: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
