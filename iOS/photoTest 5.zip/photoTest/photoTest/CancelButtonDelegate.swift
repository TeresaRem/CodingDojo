//
//  CancelButtonDelegate.swift
//  photoTest
//
//  Created by Jennifer Zeller on 9/21/16.
//  Copyright © 2016 John Morales. All rights reserved.
//

import UIKit
protocol CancelButtonDelegate: class {
    func cancelButtonPressedFrom(controller: UIViewController)
}
