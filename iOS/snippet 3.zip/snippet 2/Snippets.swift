//
//  Snippets.swift
//  snippet
//
//  Created by Elliot Young on 9/29/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import Foundation
import CoreData


class Snippets: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
