//
//  CancelButtonDelegate.swift
//  BucketList
//
//  Created by Jennifer Zeller on 9/13/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit
protocol CancelButtonDelegate: class {
    func cancelButtonPressedFrom(controller: UIViewController)
}