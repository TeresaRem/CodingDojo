//
//  MissionDetailsViewController.swift
//  BucketList
//
//  Created by Jennifer Zeller on 9/13/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class MissionDetailsViewController: UITableViewController {
    
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    
    @IBAction func doneBarButtonPressed(sender: UIBarButtonItem) {
        if let mission = missionToEdit {
            mission.setValue(newMissionTextField.text!, forKey: "details")
            delegate?.missionDetailsViewController(self, didFinishEditingMission: mission)
        } else { // we are adding so run the "didFinishAddingMission" method
            let mission = newMissionTextField.text!
            delegate?.missionDetailsViewController(self, didFinishAddingMission: mission)
        }
    }
    
    @IBOutlet weak var newMissionTextField: UITextField!
    weak var delegate: MissionDetailsViewControllerDelegate?
    weak var cancelButtonDelegate: CancelButtonDelegate?
    
    var missionToEdit: Mission?
    var missionToEditIndexPath: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        newMissionTextField.text = missionToEdit?.details
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}