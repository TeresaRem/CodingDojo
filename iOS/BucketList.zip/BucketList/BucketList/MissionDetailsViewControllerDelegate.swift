//
//  MissionDetailsViewControllerDelegate.swift
//  BucketList
//
//  Created by Jennifer Zeller on 9/13/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import Foundation
protocol MissionDetailsViewControllerDelegate: class {
    func missionDetailsViewController(controller: MissionDetailsViewController, didFinishAddingMission mission: String)
    func missionDetailsViewController(controller: MissionDetailsViewController, didFinishEditingMission mission: Mission)
}
