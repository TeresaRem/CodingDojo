//
//  TaskModel.swift
//  BucketList
//
//  Created by Jennifer Zeller on 9/20/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import Foundation
class TaskModel {
    static func getAllTasks(completionHandler: (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void) {
        let url = NSURL(string: "http://localhost:5000/tasks")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!, completionHandler: completionHandler)
        task.resume()
    }
}