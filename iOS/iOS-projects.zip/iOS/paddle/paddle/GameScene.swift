//
//  GameScene.swift
//  paddle
//
//  Created by Jennifer Zeller on 9/9/16.
//  Copyright (c) 2016 Alex. All rights reserved.
//

import SpriteKit
import CoreMotion

class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        let motionManager: CMMotionManager = CMMotionManager()
        motionManager.startAccelerometerUpdates()
        
        let paddle = SKShapeNode(rectOfSize: CGSize(width: 300, height: 100))
        paddle.fillColor = SKColor.blackColor()
        paddle.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame))
        paddle.zPosition = 1
        
        // Rectangular physics body around the object
        paddle.physicsBody = SKPhysicsBody(rectangleOfSize: paddle.frame.size)
        
        // Make it dynamic
        paddle.physicsBody!.dynamic = true
        
        // We don't want the object to fall of the screen
        paddle.physicsBody!.affectedByGravity = false
        
        // Add some mass to it
        paddle.physicsBody!.mass = 0.02
        
        // Get MotionManager data
        if let data = motionManager.accelerometerData {
            
            // Only get use data if it is "tilt enough"
            if (fabs(data.acceleration.x) > 0.2) {
                
                // Apply force to the moving object
                paddle.physicsBody!.applyForce(CGVectorMake(40.0 * CGFloat(data.acceleration.x), 0))
                
            }
        }

        
        
        
        
        
        let myLabel = SKLabelNode(fontNamed:"Chalkduster")
        myLabel.text = "Hello, World!"
        myLabel.fontSize = 45
        myLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame))
        
        self.addChild(myLabel)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       /* Called when a touch begins */
        
        for touch in touches {
            let location = touch.locationInNode(self)
            
            let sprite = SKSpriteNode(imageNamed:"Spaceship")
            
            sprite.xScale = 0.5
            sprite.yScale = 0.5
            sprite.position = location
            
            let action = SKAction.rotateByAngle(CGFloat(M_PI), duration:1)
            
            sprite.runAction(SKAction.repeatActionForever(action))
            
            self.addChild(sprite)
        }
    }
   
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}
