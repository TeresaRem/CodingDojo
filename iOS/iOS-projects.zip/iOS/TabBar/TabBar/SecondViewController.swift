//
//  SecondViewController.swift
//  TabBar
//
//  Created by Jennifer Zeller on 9/14/16.
//  Copyright © 2016 Alex. All rights reserved.
//


import UIKit
class SecondViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        print("SecondViewController viewDidLoad")
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        print("SecondViewController viewWillAppear")
    }
}
