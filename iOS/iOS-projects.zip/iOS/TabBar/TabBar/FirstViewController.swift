//
//  ViewController.swift
//  TabBar
//
//  Created by Jennifer Zeller on 9/14/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit
class FirstViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        print("FirstViewController viewDidLoad")
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        print("FirstViewController viewWillAppear")
    }
}
