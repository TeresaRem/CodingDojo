//
//  GameScene.swift
//  Circle_test
//
//  Created by Jennifer Zeller on 9/9/16.
//  Copyright (c) 2016 Alex. All rights reserved.
//

import SpriteKit
import CoreMotion

class GameScene: SKScene {
    
    let manager = CMMotionManager()
    var crosshair = SKSpriteNode()
    var attPositionX: CGFloat = CGFloat(0)
    var attPositionY: CGFloat = CGFloat(0)

    
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        let moveX: CGFloat = CGFloat(frame.size.width)
        let moveY: CGFloat = CGFloat(frame.size.height)
        
        scene?.backgroundColor = SKColor.blackColor()
        
        let OuterRing = SKShapeNode(circleOfRadius: 100 ) // Size of Circle
        OuterRing.position = CGPointMake(frame.midX, 0)  //Middle of Screen
        OuterRing.zPosition = -1.0
        OuterRing.strokeColor = SKColor.blackColor()
        OuterRing.glowWidth = 1.0
        OuterRing.fillColor = SKColor.whiteColor()
        self.addChild(OuterRing)
        
        let OuterRing2 = SKShapeNode(circleOfRadius: 80 ) // Size of Circle
        OuterRing2.position = CGPointMake(frame.midX, 0)  //Middle of Screen
        OuterRing2.zPosition = -1.0
        OuterRing2.strokeColor = SKColor.whiteColor()
        OuterRing2.glowWidth = 1.0
        OuterRing2.fillColor = SKColor.blackColor()
        self.addChild(OuterRing2)
        
        let MiddleRing = SKShapeNode(circleOfRadius: 60 ) // Size of Circle
        MiddleRing.position = CGPointMake(frame.midX, 0)  //Middle of Screen
        MiddleRing.zPosition = -1.0
        MiddleRing.strokeColor = SKColor.blackColor()
        MiddleRing.glowWidth = 1.0
        MiddleRing.fillColor = SKColor.blueColor()
        self.addChild(MiddleRing)
        
        let InnerRing = SKShapeNode(circleOfRadius: 40 ) // Size of Circle
        InnerRing.position = CGPointMake(frame.midX, 0)  //Middle of Screen
        InnerRing.zPosition = -1.0
        InnerRing.strokeColor = SKColor.blackColor()
        InnerRing.glowWidth = 1.0
        InnerRing.fillColor = SKColor.redColor()
        self.addChild(InnerRing)
        
        let BullsEye = SKShapeNode(circleOfRadius: 20 ) // Size of Circle
        BullsEye.position = CGPointMake(frame.midX, 0)  //Middle of Screen
        BullsEye.zPosition = -1.0
        BullsEye.strokeColor = SKColor.blackColor()
        BullsEye.glowWidth = 1.0
        BullsEye.fillColor = SKColor.yellowColor()
        self.addChild(BullsEye)
        
        // manager.startGyroUpdates()
        manager.deviceMotionUpdateInterval=0.1
        //        var moveAction = SKAction.moveBy(self.attPosition, duration: 0.1)
        //
        func movement() {
            //            print (self.attPositionX, self.attPositionY)
            if self.attPositionX > 0.2 {
                print("tilting right")
                crosshair.runAction(SKAction.moveTo(CGPointMake(0,0), duration: 0.1))
                
            } else if self.attPositionX < -0.2 {
                print("tilting left")
                crosshair.runAction(SKAction.moveTo(CGPointMake(frame.size.width, frame.size.height), duration: 0.1))
            }
            if self.attPositionY > 0.2 {
                print("tilting up")
                crosshair.runAction(SKAction.moveByX(0, y: moveY, duration: 0.1))
            } else if self.attPositionY < -0.2 {
                print("tilting down")
                crosshair.runAction(SKAction.moveByX(0, y: moveY * -1, duration: 0.1))
            }
        }
        manager.startDeviceMotionUpdatesToQueue(NSOperationQueue.mainQueue()){
            (data,error) in
            
            self.attPositionX = CGFloat((data?.attitude.roll)!)
            self.attPositionY = CGFloat((data?.attitude.pitch)!)
            movement()
        }
        
        
        // physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
        //        let startPosition = self.attPosition
        crosshair = SKSpriteNode(imageNamed: "crosshairs.png")
        //        crosshair.position = CGPointMake(frame.midX-500, frame.midY-500)
        //        crosshair.runAction(SKAction.moveBy(CGVector(dx: self.attPositionX, dy: self.attPositionY), duration: 0.2))
        crosshair.physicsBody = SKPhysicsBody(circleOfRadius: 20)
        crosshair.physicsBody!.affectedByGravity = false
        crosshair.physicsBody?.dynamic = true
        
        
        
        //        let myLabel = SKLabelNode(fontNamed:"Chalkduster")
        //        myLabel.text = "Hello, World!"
        //        myLabel.fontSize = 45
        //        myLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame))
        //
        //        self.addChild(myLabel)
        
        func moveSprite() {
            
            let moveUp = SKAction.moveByX(0, y: frame.size.height-100, duration: 3)
            let moveDown = SKAction.moveByX(0, y: 100-frame.size.height, duration: 3)
            let moveBackAndForth = SKAction.repeatActionForever(SKAction.sequence([moveUp, moveDown]))
            OuterRing.runAction(moveBackAndForth)
            OuterRing2.runAction(moveBackAndForth)
            MiddleRing.runAction(moveBackAndForth)
            InnerRing.runAction(moveBackAndForth)
            BullsEye.runAction(moveBackAndForth)
        }
        
        moveSprite()
        update(0.1)
        movement()
        let moveUp = SKAction.moveByX(0, y: frame.size.height-100, duration: 3)
        let moveDown = SKAction.moveByX(0, y: 100-frame.size.height, duration: 3)
        let moveBackAndForth = SKAction.repeatActionForever(SKAction.sequence([moveUp, moveDown]))
        crosshair.runAction(moveBackAndForth)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        for touch in touches {
            let location = touch.locationInNode(self)
            
            let shape = SKShapeNode(circleOfRadius: 10)
            shape.strokeColor = SKColor.blackColor()
            shape.fillColor = SKColor.greenColor()
            shape.xScale = 0.5
            shape.yScale = 0.5
            shape.position = location
            
            //            let action = SKAction.rotateByAngle(CGFloat(M_PI), duration:1)
            
            //            sprite.runAction(SKAction.repeatActionForever(action))
            
            self.addChild(shape)
        }
    }
    
    
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}