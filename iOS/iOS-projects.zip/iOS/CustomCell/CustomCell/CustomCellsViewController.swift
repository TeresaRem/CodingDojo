//
//  ViewController.swift
//  CustomCell
//
//  Created by Jennifer Zeller on 9/14/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class CustomCellsViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var nums = [1, 90, 32, 23, 9, 12, 69]
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("CustomCell") as! CustomCell
        cell.rightLabel.text = "\(nums[indexPath.row])"
        if nums[indexPath.row] > 24 {
            cell.leftButton.backgroundColor = UIColor.greenColor()
        } else {
            cell.leftButton.backgroundColor = UIColor.redColor()
        }
        // return cell so that Table View knows what to draw in each row
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nums.count
    }
}
