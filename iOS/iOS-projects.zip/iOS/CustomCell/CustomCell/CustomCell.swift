//
//  CustomCell.swift
//  CustomCell
//
//  Created by Jennifer Zeller on 9/14/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit
class CustomCell: UITableViewCell {
    @IBOutlet weak var rightLabel: UILabel!
    
    @IBOutlet weak var leftButton: UIButton!
    
}
