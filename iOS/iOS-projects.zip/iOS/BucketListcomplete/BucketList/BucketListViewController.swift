//
//  ViewController.swift
//  BucketList
//
//  Created by Jennifer Zeller on 9/13/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit
import CoreData

class BucketListViewController: UITableViewController, CancelButtonDelegate, MissionDetailsViewControllerDelegate {
    
    // create array of missions, which is a class of type NSManagedObject
    var missions = [Mission]()
    // instance to communicate with with core data, retrieve/save in NSManagedObject
    let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext

    override func viewDidLoad() {
        
        fetchAllMissions()
        super.viewDidLoad()
    }
    
    func fetchAllMissions() {
        
        // collect entities with the name Mission
        let userRequest = NSFetchRequest(entityName: "Mission")
        do {
            // try to fetch the requested entities as an array of objects
            let results = try managedObjectContext.executeFetchRequest(userRequest)
            missions = results as! [Mission]
        } catch {
            // error catch
            print("\(error)")
        }
    }
    
    func saveChanges() {
        if managedObjectContext.hasChanges {
            do {
                try managedObjectContext.save()
                print("Success")
            } catch {
                print("\(error)")
            }
        }
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // dequeue the cell from our storyboard
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell")!
        // All UITableViewCell objects have a build in textLabel so set it to the model that is corresponding to the row in array
        cell.textLabel?.text = missions[indexPath.row].details
        // return cell so that Table View knows what to draw in each row
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return missions.count
    }
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        // remove the mission at indexPath
        managedObjectContext.deleteObject(missions[indexPath.row])
        saveChanges()
        // managedObjectContext.deleteObject()
        // missions.removeAtIndex(indexPath.row)
        // reload the table view
        fetchAllMissions()
        tableView.reloadData()
    }
    func cancelButtonPressedFrom(controller: UIViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    override func tableView(tableView: UITableView, accessoryButtonTappedForRowWithIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("EditMission", sender: tableView.cellForRowAtIndexPath(indexPath))
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! MissionDetailsViewController
            controller.cancelButtonDelegate = self
            controller.delegate = self
            // Here we set the missionToEdit so that we can have the mission text on the MissionDetailsViewController
        // if sender!.tag == 0, TAGS ARE BAD BRO
        if sender is UITableViewCell{
            if let indexPath = tableView.indexPathForCell(sender as! UITableViewCell) {
                print(sender)
                controller.missionToEdit = missions[indexPath.row]
//                controller.missionToEditIndexPath = indexPath.row
            }
        }
    }
    
    func missionDetailsViewController(controller: MissionDetailsViewController, didFinishAddingMission mission: String) {
        dismissViewControllerAnimated(true, completion: nil)
        
        // create a row via newMission
        // insert new object for entity Mission
        // use scratchpad == managedObjectContext
        
        // for this table, insert a new object newMission
        
        let newMission = NSEntityDescription.insertNewObjectForEntityForName("Mission", inManagedObjectContext: managedObjectContext) as! Mission
        newMission.setValue(mission, forKey: "details")
        missions.append(newMission)
        saveChanges()
        fetchAllMissions()
        tableView.reloadData()
    }
    func missionDetailsViewController(controller: MissionDetailsViewController, didFinishEditingMission mission: Mission) {
        dismissViewControllerAnimated(true, completion: nil)
        fetchAllMissions()
        //setValue(mission, forKey: "details")
        //missions = missions.filter
        //missions.insert(mission, atIndex: indexPath)
        tableView.reloadData()
    }
    

}


