from system.core.model import Model

class List(Model):
    def __init__(self):
        super(List, self).__init__()

    def getList(self):
        query = "SELECT * FROM tasks"
        data = {"id": 0}
        tasks = self.db.query_db(query, data)
        return self.db.query_db(query, data)

    def create(self, data):
        sql = "INSERT INTO tasks (objective, created_at) VALUES "\
        "(:objective, NOW())"
        print data
        self.db.query_db(sql, data)
        return True
