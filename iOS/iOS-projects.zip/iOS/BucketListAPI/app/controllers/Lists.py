from system.core.controller import *

class Lists(Controller):
    def __init__(self, action):
        super(Lists, self).__init__(action)
        """
            This is an example of loading a model.
            Every controller has access to the load_model method.
        """
        self.load_model('List')
        self.db = self._app.db

        """
        
        This is an example of a controller method that will load a view for the client 

        """
   
    def index(self):
       
        return self.load_view('index.html')

    def tasks(self):
        allTasks = self.models["List"].getList()

        return jsonify({"response": allTasks})

    def add(self):
        self.models["List"].create(request.form)
        return jsonify({"valid": True})