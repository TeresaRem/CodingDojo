//
//  TaskModel.swift
//  BucketList
//
//  Created by Jennifer Zeller on 9/20/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import Foundation
class TaskModel {
    static func getAllTasks(completionHandler: (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void) {
        let url = NSURL(string: "http://localhost:5000/tasks")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!, completionHandler: completionHandler)
        task.resume()
    }
    static func addTaskWithObjective(objective: String, completionHandler: (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void) {
        // Create the url to request
        if let urlToReq = NSURL(string: "http://localhost:5000/tasks") {
            // Create an NSMutableURLRequest using the url. This Mutable Request will allow us to modify the headers.
            let request = NSMutableURLRequest(URL: urlToReq)
            // Set the method to POST
            request.HTTPMethod = "POST"
            // Create some bodyData and attach it to the HTTPBody
            let bodyData = "objective=\(objective)"
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            
            do {
                request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(["objective": objective], options: .PrettyPrinted)
                let session = NSURLSession.sharedSession()
                let task = session.dataTaskWithRequest(request, completionHandler: completionHandler)
                task.resume()
            } catch {
                print("Something went wrong! \(error)")
            }        }
    }

}