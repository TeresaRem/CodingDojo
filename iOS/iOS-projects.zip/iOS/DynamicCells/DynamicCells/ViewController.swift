//
//  ViewController.swift
//  DynamicCells
//
//  Created by Jennifer Zeller on 9/13/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var insertTaskField: UITextField!
    
    @IBOutlet weak var tableView: UITableView!

    @IBAction func insertButtonPressed(sender: UIButton) {
        
        if insertTaskField.text != ""{
            // Add the textField text as an item to the array
            tasks.append(insertTaskField.text!)
        }
        // reload the table view data
        tableView.reloadData()
    }
    
    var tasks = ["Exercise for 30 minutes", "Wireframe for some project", "Do laundry"]
    
    // How many cells are we going to need?
    func tableView(sender: UITableView, numberOfRowsInSection: Int) -> Int {
        // return an integer that indicates how many rows (cells) to draw
        return tasks.count
    }
    
    // How should I create each cell?
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // dequeue the cell from our storyboard
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell")!
        // if the cell has a text label, set it to the model that is corresponding to the row in array
        cell.textLabel?.text = tasks[indexPath.row]
        // return cell so that Table View knows what to draw in each row
        return cell
    }
    
    // delete function
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Section: \(indexPath.section) and Row: \(indexPath.row)")
        tasks.removeAtIndex(indexPath.row)
        tableView.reloadData()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

