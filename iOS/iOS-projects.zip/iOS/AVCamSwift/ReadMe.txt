### Swift Version of AVCam for iOS ###

===========================================================================
DESCRIPTION:

This this a swift version of AVCam . rewrites by alex.chan  2014.11.21
project url: 

AVCam demonstrates usage of AV Foundation capture API for recording movies, taking still images, and switching cameras. It functions only on an actual device, either an iPad or iPhone. There is no camera access from the simulator.

===========================================================================
BUILD REQUIREMENTS:

Xcode 5.0 or later, iOS SDK 7.0 or later

===========================================================================
RUNTIME REQUIREMENTS:

iOS 7.0 or later

===========================================================================
CHANGES FROM PREVIOUS VERSION:

Rewrote to take advantage of modern Cocoa Touch features.

===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
