//
//  PeronCell.swift
//  StarWarsEncyclopedia
//
//  Created by Jennifer Zeller on 9/19/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit
class PersonCell: UITableViewCell {
}
