//
//  DetailsViewController.swift
//  StarWarsEncyclopedia
//
//  Created by Jennifer Zeller on 9/19/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label4: UILabel!
    
    override func viewDidLoad() {
    }

}