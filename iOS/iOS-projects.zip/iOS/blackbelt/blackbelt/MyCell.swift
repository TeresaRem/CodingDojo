//
//  MyCell.swift
//  blackbelt
//
//  Created by Jennifer Zeller on 9/26/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class MyCell: UITableViewCell {
    
    
    @IBOutlet weak var taskLabel: UILabel!

    @IBOutlet weak var dateLabel: UILabel!
    
}
