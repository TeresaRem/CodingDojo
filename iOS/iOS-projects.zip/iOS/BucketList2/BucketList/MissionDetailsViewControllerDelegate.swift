//
//  MissionDetailsViewControllerDelegate.swift
//  BucketList
//
//  Created by User on 9/13/16.
//  Copyright © 2016 User. All rights reserved.
//

import Foundation
protocol MissionDetailsViewControllerDelegate: class {
    func missionDetailsViewController(controller: MissionDetailsTableViewController, didFinishAddingMission mission: String)
    func missionDetailsViewControllerEdit(controller: MissionDetailsTableViewController, didFinishAddingMission mission: Mission)
}