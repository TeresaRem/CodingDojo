//
//  ViewController.swift
//  BucketList
//
//  Created by User on 9/13/16.
//  Copyright © 2016 User. All rights reserved.
//

import UIKit
import CoreData

class BucketListViewController: UITableViewController, CancelButtonDelegate, MissionDetailsViewControllerDelegate {

    //var missions = ["Sky diving", "Live in Hawaii"]
    var missions = [String]()
    let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        fetchAllMissions()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // dequeue the cell from our storyboard
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell")!
        // All UITableViewCell objects have a build in textLabel so set it to the model that is corresponding to the row in array
        cell.textLabel?.text = missions[indexPath.row]
        // return cell so that Table View knows what to draw in each row
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return missions.count
    }
    
    func cancelButtonPressedFrom(controller: UIViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func tableView(tableView: UITableView, accessoryButtonTappedForRowWithIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("EditMission", sender: tableView.cellForRowAtIndexPath(indexPath))
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let navigationController = segue.destinationViewController as! UINavigationController
        let controller = navigationController.topViewController as! MissionDetailsTableViewController
        controller.cancelButtonDelegate = self
        controller.delegate = self
//        if segue.identifier == "EditMission" {
//            if let indexPath = tableView.indexPathForCell(sender as! UITableViewCell) {
//                //controller.missionToEdit = missions[indexPath.row]
//                //controller.missionToEditIndexPath = indexPath.row
//            }
//        }
    }
    
    func missionDetailsViewController(controller: MissionDetailsTableViewController, didFinishAddingMission mission: String) {
        dismissViewControllerAnimated(true, completion: nil)
        appendMission(mission)
        fetchAllMissions()
        tableView.reloadData()
    }
    
    func missionDetailsViewControllerEdit(controller: MissionDetailsTableViewController, didFinishAddingMission mission: Mission) {
        dismissViewControllerAnimated(true, completion: nil)
        //fetchAllMissions()
        tableView.reloadData()
    }
    
    
//    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath:NSIndexPath) {
//        deleteMission(missions[indexPath.row])
//        //fetchAllMissions()
//        tableView.reloadData()
//    }
    
    func fetchAllMissions() {
        TaskModel.getAllTasks(){
            data, response, error in
            do {
                if let tasks = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSDictionary {
                    if let results = tasks["response"] {
                        let resultsArray = results as! NSArray
                        self.missions = [String]()
                        for task in resultsArray {
                            if let objective = task["objective"]{
                                self.missions.append(String(objective!))
                            }
                        }
                    }
                }
                dispatch_async(dispatch_get_main_queue(),{
                    self.tableView.reloadData()
                })
            } catch {
                print("Something went wrong")
            }
        }
    }
    
    func appendMission(input: String) {
//        let mission = NSEntityDescription.insertNewObjectForEntityForName("Mission", inManagedObjectContext: managedObjectContext) as! Mission
//        mission.details = input
//        
//        if managedObjectContext.hasChanges {
//            do {
//                try managedObjectContext.save()
//                print("Success")
//            } catch {
//                print("\(error)")
//            }
//        }
        
        TaskModel.addTaskWithObjective(input, completionHandler: {
            data, response, error in
            
        })
    }
    
//    func deleteMission(input: Mission) {
//        managedObjectContext.deleteObject(input)
//        
//        if managedObjectContext.hasChanges {
//            do {
//                try managedObjectContext.save()
//            } catch {
//                print("\(error)")
//            }
//        }
//    
//    }



}

