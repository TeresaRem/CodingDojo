//
//  MissionDetailsTableViewController.swift
//  BucketList
//
//  Created by User on 9/13/16.
//  Copyright © 2016 User. All rights reserved.
//

import UIKit

class MissionDetailsTableViewController: UITableViewController {
    
    var missionToEdit: Mission?
    //var missionToEditIndexPath: Int?

    weak var cancelButtonDelegate: CancelButtonDelegate?
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    
    @IBOutlet weak var newMissionTextField: UITextField!
    
    weak var delegate: MissionDetailsViewControllerDelegate?
    @IBAction func doneBarButtonPressed(sender: UIBarButtonItem) {
        if let mission = missionToEdit {
            mission.details = newMissionTextField.text!
            delegate?.missionDetailsViewControllerEdit(self, didFinishAddingMission: mission)
        } else {
            let mission = newMissionTextField.text!
            delegate?.missionDetailsViewController(self, didFinishAddingMission: mission)
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    

    

   
}
