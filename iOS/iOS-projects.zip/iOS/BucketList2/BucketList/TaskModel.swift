//
//  TaskModel.swift
//  BucketList
//
//  Created by User on 9/20/16.
//  Copyright © 2016 User. All rights reserved.
//

import Foundation
class TaskModel {
    static func getAllTasks(completionHandler: (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void) {
        let url = NSURL(string: "http://localhost:5000/tasks")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!, completionHandler: completionHandler)
        task.resume()
    }
    
    static func addTaskWithObjective(objective: String, completionHandler: (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void) {
        // Create the url to request
        if let urlToReq = NSURL(string: "http://localhost:5000/tasks") {
            // Create an NSMutableURLRequest using the url. This Mutable Request will allow us to modify the headers.
            let request = NSMutableURLRequest(URL: urlToReq)
            // Set the method to POST
            request.HTTPMethod = "POST"
            // Create some bodyData and attach it to the HTTPBody
            let bodyData = "objective=\(objective)"
            request.HTTPBody = bodyData.dataUsingEncoding(NSUTF8StringEncoding)
            // Create the session
            let session = NSURLSession.sharedSession()
            let task = session.dataTaskWithRequest(request, completionHandler: completionHandler)
            task.resume()
        }
    }
    

}