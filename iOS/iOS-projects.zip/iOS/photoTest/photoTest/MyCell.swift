//
//  MyCell.swift
//  photoTest
//
//  Created by Jennifer Zeller on 9/21/16.
//  Copyright © 2016 John Morales. All rights reserved.
//

import UIKit
class MyCell: UITableViewCell {
    
    @IBOutlet weak var travelImage: UIImageView!
    
    @IBOutlet weak var dateAndTimeLabel: UILabel!
    
    @IBOutlet weak var commentLabel: UILabel!
    
}
