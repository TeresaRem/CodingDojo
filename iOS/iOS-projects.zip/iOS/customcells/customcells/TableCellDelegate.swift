//
//  TableCellDelegate.swift
//  customcells
//
//  Created by Elliot Young on 9/15/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import Foundation
import UIKit

protocol TableCellDelegate: class {
    func buttonPressedFrom(Cell: tableCell)
}