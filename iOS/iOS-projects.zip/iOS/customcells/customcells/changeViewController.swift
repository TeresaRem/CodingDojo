//
//  changeViewController.swift
//  customcells
//
//  Created by Elliot Young on 9/15/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import UIKit

class ChangeViewController: UIViewController {
    
    weak var cancelButtonDelegate1: cancelButtonDelegate?
    // weak var doneButtonDelegate: DoneButtonDelegate?
    weak var delegate: changeViewControllerDelegate?
    
    var momentToEdit: String?
    var momentToEditAtIndexPath: Int?
    
    
// remnant from the UITableViewController storyboard. This was deleted in favor of a UIViewController
//    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
//        
//        cancelButtonDelegate1?.cancelButtonPressedFrom(self)
//    }
    
    @IBAction func cancelButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate1?.cancelButtonPressedFrom(self)
    }
    
    @IBOutlet weak var addName: UITextField!
    @IBOutlet weak var addDescription: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        addName.text = momentToEdit
    
    }
    
    @IBAction func DoneButtonPressed(sender: UIBarButtonItem) {
        // doneButtonDelegate?.DoneButtonPressedFrom(self)
        
       
        
        if let momentEdit = momentToEdit{
            var newMomentToEdit = momentEdit
            newMomentToEdit = addName.text!
            delegate?.changeViewController(self, didFinishEditingMoment: newMomentToEdit, atIndexPath: momentToEditAtIndexPath! )
        }
        else{
            
            delegate?.changeViewController(self, didFinishAddingMoment: addName.text!)
            print("boss tycoon dipped in sauce")
        }
    }
}
