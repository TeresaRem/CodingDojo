//
//  changeViewControllerDelegate.swift
//  customcells
//
//  Created by Elliot Young on 9/15/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import UIKit
protocol changeViewControllerDelegate: class {
    
    func changeViewController(controller: ChangeViewController,didFinishAddingMoment moment: String)
    
    func changeViewController(controller: ChangeViewController,didFinishEditingMoment moment: String, atIndexPath indexPath: Int)
}