//
//  tablecell.swift
//  customcells
//
//  Created by Elliot Young on 9/15/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import Foundation
import UIKit

class tableCell: UITableViewCell {
    var buttonDelegate:TableCellDelegate?
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var customImage: UIImageView!
    @IBAction func editPressed(sender: UIButton) {
        buttonDelegate?.buttonPressedFrom(self)
    }
}