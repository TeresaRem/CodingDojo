//
//  ViewController.swift
//  customcells
//
//  Created by Elliot Young on 9/15/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, TableCellDelegate, cancelButtonDelegate, changeViewControllerDelegate {
    
    var array = ["star","plank","crab","squid"]
    // change array to be type [Moment]
    // Moment is a class

    override func viewDidLoad() {
        super.viewDidLoad()
        print("we are loaded")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func buttonPressedFrom(Cell: tableCell) {
        print("do things")
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("prototype") as! tableCell
        cell.buttonDelegate = self
        cell.nameLabel.text = array[indexPath.row]
        cell.customImage.image = UIImage(named: array[indexPath.row])
        return cell
    }
    
    override func tableView(tableView: UITableView, accessoryButtonTappedForRowWithIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("editMoment", sender: tableView.cellForRowAtIndexPath(indexPath))
        
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        array.removeAtIndex(indexPath.row)
        tableView.reloadData()
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if (segue.identifier == "addMomentButtonPressed") {
            
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! ChangeViewController
            controller.cancelButtonDelegate1 = self
            controller.delegate = self
            print("hello.. addbuttonpressed")
            
        }
        
        else if (segue.identifier == "editMoment"){
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! ChangeViewController
            controller.cancelButtonDelegate1 = self
            controller.delegate = self
            print("hello.. editMoment")
            
            if let indexPath = tableView.indexPathForCell(sender as! UITableViewCell){
                controller.momentToEdit = array[indexPath.row]
                controller.momentToEditAtIndexPath = indexPath.row
            }
        }
        
    }
    
    func cancelButtonPressedFrom(controller: UIViewController){
        
            dismissViewControllerAnimated(true, completion: nil)
    }
    
    func changeViewController(controller: ChangeViewController, didFinishAddingMoment moment: String) {
        dismissViewControllerAnimated(true, completion: nil)
        array.append(moment)
        tableView.reloadData()
    }
    
    func changeViewController(controller: ChangeViewController,didFinishEditingMoment moment: String, atIndexPath indexPath: Int){
        dismissViewControllerAnimated(true, completion: nil)
        print("heyhey")
        print(moment)
        print(indexPath)
        array[indexPath] = moment
        tableView.reloadData()
    }
    
   
    
    
//    func doneButtonPressedFrom(controller: UIViewController){
//        // append to array
//        dismissViewControllerAnimated(true, completion: nil)
//
//    }

    


}

