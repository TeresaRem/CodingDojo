//
//  DoneButtonDelegate.swift
//  customcells
//
//  Created by Elliot Young on 9/15/16.
//  Copyright © 2016 Elliot Young. All rights reserved.
//

import UIKit

protocol DoneButtonDelegate: class {
    
    func doneButtonPressedFrom(controller: UIViewController)
    
}