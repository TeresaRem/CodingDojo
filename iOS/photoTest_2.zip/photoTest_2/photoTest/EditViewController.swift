//
//  EditViewController.swift
//  photoTest
//
//  Created by Jennifer Zeller on 9/21/16.
//  Copyright © 2016 John Morales. All rights reserved.
//

import UIKit

class EditViewController: UIViewController{
    
    var commentString:String?
    var imageEdit:UIImage?
    var appendThisIndex:Int?
    var timeStamp:NSDate?
    
    weak var cancelButtonDelegate: CancelButtonDelegate?
    
    @IBOutlet weak var commentText: UITextField!
    
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    @IBAction func doneBarButtonPressed(sender: UIBarButtonItem) {
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        if let indexEdit = appendThisIndex{
            if commentText.text == ""{
                comments[indexEdit] = "no comment"
            }else{
                comments[indexEdit] = commentText.text!
            }
//            print("image")
//            if let editImage = newImage{
//                logImages[indexEdit] = editImage
//            } else{
//                logImages.append(UIImage(named: "jay")!)
//            }
//            print("done")
        } else{
            if (timeStamp != nil){
                dates.append(dateFormatter.stringFromDate(timeStamp!))
            }
            if commentText.text == ""{
                comments.append("no comment")
            }else if let comment = commentText.text{
                comments.append(comment)
            }else{
                comments.append("no comment")
            }
            
            if let addImage = newImage{
                logImages.append(newImage)
            } else{
                logImages.append(UIImage(named: "jay")!)
            }
        }
        
        NSNotificationCenter.defaultCenter().postNotificationName("load", object: nil)
        self.view.window!.rootViewController?.dismissViewControllerAnimated(false, completion: nil)
    }
    
    @IBOutlet weak var entryImage: UIImageView!
    var newImage: UIImage!
    
    override func viewDidLoad() {
        if let editComment = commentString{
            commentText.text = editComment
        }
        if let editNewImage = imageEdit{
            entryImage.image = editNewImage
        } else{
            entryImage.image = newImage
        }
        super.viewDidLoad()
    }
}
