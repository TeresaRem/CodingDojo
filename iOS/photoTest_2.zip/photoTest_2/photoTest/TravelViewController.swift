//
//  TravelViewController.swift
//  photoTest
//
//  Created by Jennifer Zeller on 9/21/16.
//  Copyright © 2016 John Morales. All rights reserved.
//

import UIKit
import SimplePDF
// var dates = [dateFormatter.stringFromDate(NSDate()),dateFormatter.stringFromDate(NSDate())]
let dateFormatter = NSDateFormatter()
var dates = ["9-22-2016 9:00","9-22-2016 9:00"]
var comments = ["jay is so handsome","<3"]
var logImages: [UIImage] = [UIImage(named: "jay")!,UIImage(named: "jay")!]
var docController: UIDocumentInteractionController?


class TravelViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, CancelButtonDelegate{

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(TravelViewController.loadList(_:)),name:"load", object: nil)
        // need to use date formatter!!!
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
    }
    func cancelButtonPressedFrom(controller: UIViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func tableView(tableView: UITableView, accessoryButtonTappedForRowWithIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("EditCell", sender: tableView.cellForRowAtIndexPath(indexPath))
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "AddPhoto" {
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! CameraViewController
            controller.cancelButtonDelegate = self
        }
        if segue.identifier == "EditCell" {
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! EditViewController
            controller.cancelButtonDelegate = self
            if let indexPath = self.tableView.indexPathForCell(sender as! UITableViewCell) {
                controller.commentString = comments[indexPath.row]
                controller.imageEdit = logImages[indexPath.row]
                controller.appendThisIndex = indexPath.row
            }
        }
    }
    

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return logImages.count
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell") as! MyCell
        
        cell.travelImage.image = logImages[indexPath.row]
        
        if indexPath.row < dates.count{
            cell.dateAndTimeLabel.text = "\(dates[indexPath.row])"
        }else {
            cell.dateAndTimeLabel.text = "date unknown"
        }
        
        if indexPath.row < comments.count{
           cell.commentLabel.text = "\(comments[indexPath.row])"
        } else{
            cell.commentLabel.text = "click to edit"
        }
        // return cell so that Table View knows what to draw in each row
        return cell
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        // remove the mission at indexPath
        if indexPath.row < dates.count{
            dates.removeAtIndex(indexPath.row)
        }
        if indexPath.row < comments.count{
        comments.removeAtIndex(indexPath.row)
        }
        if indexPath.row < logImages.count{
            logImages.removeAtIndex(indexPath.row)
        }
        // reload the table view
        tableView.reloadData()
    }

    @IBAction func createPDFPressed(sender: UIButton) {
        let paperSize = CGSize(width: 595, height: 842)
        let pdf = SimplePDF(pageSize: paperSize, pageMargin: 20.0)
        var filePath: String?
        
        for i in 0..<dates.count {
            pdf.setContentAlignment(.Left)
            pdf.addText("Photologue")
            pdf.addLineSeparator()
            pdf.addLineSpace(30)
            pdf.addImage(logImages[i])
            pdf.addText(dates[i])
            pdf.addText(comments[i])
            if i != dates.count - 1 {
                pdf.beginNewPage()
            }
            
        }
        
        // generate PDF
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first {
            
            let fileName = "example.pdf"
            let documentsFileName = documentDirectories + "/" + fileName
            
            let pdfData = pdf.generatePDFdata()
            do{
                try pdfData.writeToFile(documentsFileName, options: .DataWritingAtomic)
                print("\nThe generated pdf can be found at:")
                print("\n\t\(documentsFileName)\n")
                filePath = documentsFileName
            }catch{
                print(error)
            }
        }
        //
        // if let path = NSBundle.mainBundle().pathForResource("example", ofType: "pdf") {
        if let path = filePath {
            print("path passed")
            let targetURL = NSURL.fileURLWithPath(path)
                docController = UIDocumentInteractionController(URL: targetURL)
                let url = NSURL(string:"itms-books:");
                if UIApplication.sharedApplication().canOpenURL(url!) {
                    docController!.presentOpenInMenuFromRect(CGRectZero, inView: self.view, animated: true)
                    print("iBooks is installed")
                }else{
                    print("iBooks is not installed")
                }
                
            
        }
    }
    
    func loadList(notification: NSNotification){
        //load data here
        self.tableView.reloadData()
    }


}